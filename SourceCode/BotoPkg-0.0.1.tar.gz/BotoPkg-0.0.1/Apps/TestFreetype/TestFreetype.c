/** @file TestFreetype.c

  HII test application

**/

/*=============================================================================
							  EDIT HISTORY

  $Header:
  $DateTime: 2012-02-13 00:26:40 $
  $Author: William.L $

 when       who     what, where, why
 --------   ---     -----------------------------------------------------------
 02/13/12   William.L    Init.

=============================================================================*/

/*=========================================================================
	  Include Files
==========================================================================*/
#include "TestFreetype.h"

/*=========================================================================
	  Functions
==========================================================================*/
/**
  Test HiiTest application entry point.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The entry point is executed successfully.
  @retval other             Some error occurs when executing this entry point.

**/

EFI_STATUS
EFIAPI
TestFreetypeMain(
	IN EFI_HANDLE         ImageHandle,
	IN EFI_SYSTEM_TABLE   *SystemTable
)
{
	EFI_STATUS                      Status;
	// EFI_HII_HANDLE                 /* HiiHandle,*/ HiiHandleFont;
	// EFI_SCREEN_DESCRIPTOR           Screen;

	SystemTable->ConOut->ClearScreen(SystemTable->ConOut);  /* Clear screen */


	EFI_GRAPHICS_OUTPUT_PROTOCOL* GraphicsOutput;
	EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
	UINTN InfoSize;
	UINT32 uBestMode = 0;
	EFI_GRAPHICS_OUTPUT_MODE_INFORMATION mInfoBest;
	mInfoBest.HorizontalResolution = 0;
	mInfoBest.VerticalResolution = 0;

	Status = gBS->LocateProtocol(&gEfiGraphicsOutputProtocolGuid,
		NULL, (VOID **)&GraphicsOutput);
	if (EFI_ERROR(Status))
	{
		Print(L"    LocatePortocol Failed with status %r\n", Status);
		return Status;
	}
	for (UINT32 i = 0; i < GraphicsOutput->Mode->MaxMode; i++)
	{
		Print(L"Mode %d\n", i);
		Status = GraphicsOutput->QueryMode(GraphicsOutput, i, &InfoSize, &Info);
		if (EFI_ERROR(Status))
		{
			Print(L"    QueryMody %r\n", Status);
			break;
		}
		else
		{
			Print(L"   Version %x, Width: %d, Height: %d, ScanLine: %d\n",
				Info->Version, Info->HorizontalResolution,
				Info->VerticalResolution, Info->PixelsPerScanLine);
			if(Info->HorizontalResolution > mInfoBest.HorizontalResolution)
			{
				mInfoBest.HorizontalResolution = Info->HorizontalResolution;
				mInfoBest.VerticalResolution = Info->VerticalResolution;
				uBestMode = i;
			}
		}
		FreePool(Info);
	}

	Status = GraphicsOutput->SetMode(GraphicsOutput, uBestMode);

		//  TestStatus("HiiTestApp", EFI_SUCCESS);
		//  TEST_STOP("HiiTestApp");
	if (EFI_ERROR(Status))
	{
		Print(L"    GraphicsOutput->SetMode Failed with status %r\n", Status);
		return Status;
	}
	else
	{
		SystemTable->ConOut->ClearScreen(SystemTable->ConOut);  /* Clear screen */
		Print(L"....... Working with best Graphic Mode\n");
	}
	return EFI_SUCCESS;
}

