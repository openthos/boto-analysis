/** @file TestFreetype.h
   
  Query Graphics output Modes.

**/

/* ==============================================================================
                              EDIT HISTORY

  $Header:  $
  $DateTime: 2016/07/25 13:10:45 $
  $Author: David Chan $
  $Mail: chanuei@sina.com

 when       who           what, where, why
 --------   ---           ----------------------------------------------------------
 2016/07/25 David Chan    Init.

==============================================================================*/

#ifndef _TEST_FREETYPE_H_
#define _TEST_FREETYPE_H_

/*=========================================================================
      Include Files
==========================================================================*/
#include <Uefi.h>

#include <Protocol/HiiConfigRouting.h>
#include <Protocol/FormBrowser2.h>
#include <Protocol/HiiConfigAccess.h>
#include <Protocol/HiiDatabase.h>
#include <Protocol/HiiString.h>

#include <Guid/MdeModuleHii.h>

#include <Library/HiiLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiDriverEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/MemoryAllocationLib.h>

#include <Library/UefiLib.h>
#include <Library/BaseLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/DebugLib.h>   /* DEBUG macro */
#include <Library/PrintLib.h>   /* AsciiPrint */

#endif 
