/** @file QueryMode.c
   
  Query Graphics output Modes.
  
**/

#==============================================================================
#                              EDIT HISTORY
#
#  $Header:  $
#  $DateTime: 2016/07/25 13:10:45 $
#  $Author: David Chan $
#  $Mail: chanuei@sina.com
#
# when       who           what, where, why
# --------   ---           ----------------------------------------------------------
# 2016/07/25 David Chan    Init.
#
#==============================================================================

/*=========================================================================
      Include Files
==========================================================================*/
#include "QueryMode.h"

/*=========================================================================
      Functions
==========================================================================*/
/**
  Test HiiTest application entry point. 

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.  
  @param[in] SystemTable    A pointer to the EFI System Table.
  
  @retval EFI_SUCCESS       The entry point is executed successfully.
  @retval other             Some error occurs when executing this entry point.

**/

EFI_STATUS
EFIAPI
QueryModeMain (
  IN EFI_HANDLE         ImageHandle,
  IN EFI_SYSTEM_TABLE   *SystemTable
  )
{
  EFI_STATUS                      Status;
  // EFI_HII_HANDLE                 /* HiiHandle,*/ HiiHandleFont;
  // EFI_SCREEN_DESCRIPTOR           Screen;

  SystemTable->ConOut->ClearScreen(SystemTable->ConOut);  /* Clear screen */


  EFI_GRAPHICS_OUTPUT_PROTOCOL* GraphicsOutput;
  EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
  UINTN InfoSize;

  Status = gBS->LocateProtocol(&gEfiGraphicsOutputProtocolGuid,
	                             NULL, (VOID **)&GraphicsOutput);
  if (EFI_ERROR(Status))
	{
		Print(L"    LocatePortocol Failed with status %r\n", Status);
		return Status;
	}	
	for (UINTN i=0; i<GraphicsOutput->Mode->MaxMode; i++)
	{
		Print(L"Mode %d\n", i);
		Status = GraphicsOutput->QueryMode(GraphicsOutput, i, &InfoSize, &Info);
		if (EFI_ERROR(Status))
		{
			Print(L"    QueryMody %r\n", Status);
			break;
		}
		else
		{
			Print(L"   Version %x, Width: %d, Height: %d, ScanLine: %d\n",
			    Info->Version, Info->HorizontalResolution,
			    Info->VerticalResolution, Info->PixelsPerScanLine);
		}
		FreePool (Info);
	}
//  TestStatus("HiiTestApp", EFI_SUCCESS);
//  TEST_STOP("HiiTestApp");
  
  return EFI_SUCCESS;
}

