EFI_STATUS
security_policy_install(void);
EFI_STATUS
security_policy_uninstall(void);
// void
// security_protocol_set_hashes(unsigned char *esl, int len);
