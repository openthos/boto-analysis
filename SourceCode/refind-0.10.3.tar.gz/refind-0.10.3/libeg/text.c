/*
 * libeg/text.c
 * Text drawing functions
 *
 * Copyright (c) 2006 Christoph Pfisterer
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *  * Neither the name of Christoph Pfisterer nor the names of the
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "libegint.h"
#include "../refind/global.h"

#include "egemb_font.h"
#define FONT_NUM_CHARS 96

static EG_IMAGE *BaseFontImage = NULL;
static EG_IMAGE *DarkFontImage = NULL;
static EG_IMAGE *LightFontImage = NULL;

static UINTN FontCellWidth = 8;
#define HII_GLYPH_WIDTH 8
#define HII_GLYPH_HEIGHT 19

//
// Text rendering
//

static VOID egPrepareFont() {
//   if (HiiFont == NULL) {
//	   EFI_STATUS  Status = gBS->LocateProtocol (&gEfiHiiFontProtocolGuid, NULL, (VOID **) &HiiFont);
//	   CopyMem(SystemFont.Font.FontInfo.FontName, (const CHAR16*)L"Yahei", StrLen((const CHAR16*)L"Yahei")*2 +2);
//	   if(EFI_ERROR(Status))
//		   return;
//   }
//   if (HiiFont != NULL)
      FontCellWidth = HII_GLYPH_WIDTH;
} // VOID egPrepareFont();

UINTN egGetFontHeight(VOID) {
   egPrepareFont();
   return HII_GLYPH_HEIGHT;
} // UINTN egGetFontHeight()

UINTN egGetFontCellWidth(VOID) {
   return FontCellWidth;
}

UINTN egComputeTextWidth(IN CHAR16 *Text) {
   UINTN Width = 0;
   UINTN TextLen = 0;

   egPrepareFont();
   if (Text != NULL)
   {
	    for(UINTN i=0; i<StrLen(Text); i++)
	    {
	    	if((0x20<=Text[i]&&Text[i]<=0x7e) || ((0xff60<Text[i])&&(Text[i]<=0xff9f)) || ((0xffE7<Text[i])&&(Text[i]<=0xffEE)))
	    		TextLen += 1;
	    	else/* if((Text[i]>=0x3000 && Text[i]<=0x303f) || (Text[i]>=0x4e00 && Text[i]<=0x9fa4))*/
	    		TextLen += 2;
	    }
   }
      Width = FontCellWidth * TextLen;
   return Width;
} // UINTN egComputeTextWidth()

VOID egMeasureText(IN CHAR16 *Text, OUT UINTN *Width, OUT UINTN *Height)
{
    egPrepareFont();

    if (Width != NULL)
        *Width = egComputeTextWidth(Text);
    if (Height != NULL)
        *Height = egGetFontHeight();
}

VOID egRenderText(IN CHAR16 *Text, IN OUT EG_IMAGE *CompImage, IN UINTN PosX, IN UINTN PosY, IN UINT8 BGBrightness)
{
    EG_IMAGE        *FontImage;
    EG_PIXEL        *BufferPtr;
    EG_PIXEL        *FontPixelData;
    UINTN           BufferLineOffset, FontLineOffset;
    UINTN           TextLength,TextWidth,TextHeight;

    EFI_STATUS                           Status = 0;


    EFI_HII_FONT_PROTOCOL   *HiiFont = NULL;
//
//
//
//	egPrepareFont();
//
//    // clip the text
    egMeasureText(Text, &TextWidth, &TextHeight);


    TextLength = TextWidth / FontCellWidth;

//    Print(L"TextLength is %d\n", TextLength);

//    if (TextLength * FontCellWidth + PosX > CompImage->Width)
//        TextLength = (CompImage->Width - PosX) / FontCellWidth;



    EFI_GRAPHICS_OUTPUT_PROTOCOL         *gGraphicsOutput;
    EFI_IMAGE_OUTPUT                     gSystemFrameBuffer;
    EFI_IMAGE_OUTPUT*                    pSystemFrameBuffer  = &gSystemFrameBuffer;

    struct PRIVATE_EFI_FONT_DISPLAY_INFO
    {
        EFI_FONT_DISPLAY_INFO Font;
        CHAR16 Name[31];
    } SystemFont= {{
        {0xFF,0xFF,0xFF,0xFF}, // BGRA ForeColor
        {0x00,0x00,0x00,0x00}, // BackColor
        EFI_FONT_INFO_ANY_FONT,
        {EFI_HII_FONT_STYLE_NORMAL, 19, L'Y'}
    }, {}};

    Status = gBS->LocateProtocol (&gEfiHiiFontProtocolGuid, NULL, (VOID **) &HiiFont);

//    gBS->LocateProtocol(&gEfiGraphicsOutputProtocolGuid,NULL,(VOID **)&gGraphicsOutput);
//    gSystemFrameBuffer.Width = (UINT16) gGraphicsOutput->Mode->Info->HorizontalResolution;
//    gSystemFrameBuffer.Height = (UINT16) gGraphicsOutput->Mode->Info->VerticalResolution;
    gSystemFrameBuffer.Width = TextWidth;
    gSystemFrameBuffer.Height = TextHeight;
//    gSystemFrameBuffer.Image.Screen = gGraphicsOutput;
    gSystemFrameBuffer.Image.Bitmap = (UINT8 *)AllocateZeroPool(TextWidth*TextHeight*sizeof(EFI_GRAPHICS_OUTPUT_BLT_PIXEL));
    CopyMem(SystemFont.Font.FontInfo.FontName, (const CHAR16*)L"Yahei", StrLen((const CHAR16*)L"Yahei")*2 +2);



	if (HiiFont != NULL && gSystemFrameBuffer.Image.Bitmap!=NULL)
	{
	    Status = HiiFont->StringToImage (
	            HiiFont,
	            EFI_HII_IGNORE_IF_NO_GLYPH | EFI_HII_OUT_FLAG_CLIP |
	            EFI_HII_OUT_FLAG_CLIP_CLEAN_X | EFI_HII_OUT_FLAG_CLIP_CLEAN_Y |
	//            EFI_HII_IGNORE_LINE_BREAK | EFI_HII_OUT_FLAG_TRANSPARENT | EFI_HII_DIRECT_TO_SCREEN ,
	            EFI_HII_IGNORE_LINE_BREAK | EFI_HII_OUT_FLAG_TRANSPARENT ,
	            Text,
	            (const EFI_FONT_DISPLAY_INFO*)(&SystemFont.Font),
	//            &pSystemFrameBuffer,
	            &pSystemFrameBuffer,
	            0, 0,
	            0, 0,
	            0
	            );


//		for(UINTN n=0; n < TextWidth*TextHeight; n++)
//		{
//			CompImage->PixelData[n].b = 0xFF;
//			CompImage->PixelData[n].g = 0xFF;
//			CompImage->PixelData[n].r = 0xFF;
//		}
		for(UINTN y=0; y<TextHeight; y++)
		{
			for(UINTN x=0; x<TextWidth; x++)
			{
				if(BGBrightness < 128)
				{
					if(		   gSystemFrameBuffer.Image.Bitmap[y*TextWidth+x].Blue ==0
							&& gSystemFrameBuffer.Image.Bitmap[y*TextWidth+x].Green ==0
							&& gSystemFrameBuffer.Image.Bitmap[y*TextWidth+x].Red ==0
					){
					//	Print(L"Blank Ligth Hit\r\n");
					}
					else
					{
						CompImage->PixelData[PosY*CompImage->Width+PosX+y*CompImage->Width+x].b = 0xFF;
						CompImage->PixelData[PosY*CompImage->Width+PosX+y*CompImage->Width+x].g = 0xFF;
						CompImage->PixelData[PosY*CompImage->Width+PosX+y*CompImage->Width+x].r = 0xFF;
//						CompImage->PixelData[y*CompImage->Width+x].b = 0xFF;
//						CompImage->PixelData[y*CompImage->Width+x].g = 0xFF;
//						CompImage->PixelData[y*CompImage->Width+x].r = 0xFF;
					}

				}
				else
				{
					if(gSystemFrameBuffer.Image.Bitmap[y*TextWidth+x].Blue ==0
							&& gSystemFrameBuffer.Image.Bitmap[y*TextWidth+x].Green ==0
							&& gSystemFrameBuffer.Image.Bitmap[y*TextWidth+x].Red ==0
					){
					//	Print(L"Blank Dark Hit\r\n");
					}
					else
					{
						CompImage->PixelData[PosY*CompImage->Width+PosX+y*CompImage->Width+x].b = 0;
						CompImage->PixelData[PosY*CompImage->Width+PosX+y*CompImage->Width+x].g = 0;
						CompImage->PixelData[PosY*CompImage->Width+PosX+y*CompImage->Width+x].r = 0;
//						CompImage->PixelData[y*CompImage->Width+x].b = 0;
//						CompImage->PixelData[y*CompImage->Width+x].g = 0;
//						CompImage->PixelData[y*CompImage->Width+x].r = 0;
					}
				}

			}
		}
	}
//	FreePool(TextImageOutput.Image.Bitmap);
	FreePool(gSystemFrameBuffer.Image.Bitmap);
}

// Load a font bitmap from the specified file
VOID egLoadFont(IN CHAR16 *Filename) {
   if (BaseFontImage)
      egFreeImage(BaseFontImage);

   BaseFontImage = egLoadImage(SelfDir, Filename, TRUE);
   if (BaseFontImage == NULL)
      Print(L"Note: Font image file %s is invalid! Using default font!\n");
    egPrepareFont();
} // BOOLEAN egLoadFont()

/* EOF */
